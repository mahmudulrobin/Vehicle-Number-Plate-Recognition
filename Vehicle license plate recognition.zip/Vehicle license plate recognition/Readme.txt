1.Open GUI.m file
2.Run it